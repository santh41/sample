import json
import subprocess

class RadonAnalyzer:
    def __init__(self, repo_path):
        self.repo_path = repo_path

    def run_analysis(self):
        try:
            result = subprocess.run(
                ["radon", "cc", self.repo_path, "--json"],
                capture_output=True,
                text=True,
                cwd=self.repo_path
            )

            if not result.stdout.strip():
                raise Exception("Radon output is empty")

            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError:
                raise Exception("Failed to parse Radon output")

            issues = []
            for file_path, functions in data.items():
                if not isinstance(functions, list):
                    continue

                for function in functions:
                    if isinstance(function, str):
                        try:
                            function = json.loads(function)
                        except json.JSONDecodeError:
                            continue

                    if isinstance(function, dict) and "complexity" in function:
                        severity = self._get_severity(function["complexity"])
                        issues.append({
                            'tool': 'radon',
                            'filename': file_path,
                            'function_name': function.get("name", ""),
                            'line_number': function.get("lineno", 0),
                            'severity': severity,
                            'message': self._get_message(function["complexity"]),
                            'complexity': function["complexity"]
                        })

            return issues

        except Exception as e:
            print(f"Radon analysis error: {str(e)}")
            return []

    def _get_severity(self, complexity):
        if complexity <= 5:
            return "LOW"
        elif 6 <= complexity <= 10:
            return "MEDIUM"
        elif 11 <= complexity <= 20:
            return "HIGH"
        return "CRITICAL"

    def _get_message(self, complexity):
        if complexity <= 5:
            return "Good code quality, minimal complexity"
        elif 6 <= complexity <= 10:
            return "Manageable complexity, could be refactored"
        elif 11 <= complexity <= 20:
            return "Complex function, consider breaking it down"
        return "Very complex function, likely hard to maintain"
