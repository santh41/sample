import os
import subprocess
import requests
from django.conf import settings

class SonarQubeAnalyzer:
    def __init__(self, repo_path):
        self.repo_path = repo_path
        self.sonarqube_url = "http://localhost:9000"
        self.sonarqube_token = "sqa_277f8f55ef85294afae32af86288b134efbb088a"

    def run_analysis(self):
        project_key = os.path.basename(self.repo_path)
        
        try:
            # Run SonarScanner
            self._run_sonar_scanner(project_key)
            
            # Fetch results
            issues = self._fetch_sonar_results(project_key)
            return issues
            
        except Exception as e:
            print(f"SonarQube analysis error: {str(e)}")
            return []

    def _run_sonar_scanner(self, project_key):
        cmd = f"""
        sonar-scanner \
        -Dsonar.projectKey={project_key} \
        -Dsonar.sources=. \
        -Dsonar.host.url={self.sonarqube_url} \
        -Dsonar.login={self.sonarqube_token}
        """
        subprocess.run(cmd, shell=True, cwd=self.repo_path, check=True)

    def _fetch_sonar_results(self, project_key):
        url = f"{self.sonarqube_url}/api/issues/search?componentKeys={project_key}"
        response = requests.get(url, auth=(self.sonarqube_token, ""))
        data = response.json()

        issues = []
        for issue in data.get("issues", []):
            issues.append({
                'tool': 'sonarqube',
                'filename': issue.get("component", "N/A"),
                'line_number': issue.get("line", 0),
                'severity': issue.get("severity", "INFO").upper(),
                'message': issue.get("message", ""),
                'type': issue.get("type", "")
            })

        return issues
