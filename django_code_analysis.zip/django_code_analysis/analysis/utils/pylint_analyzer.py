import json
import subprocess
import os
from django.conf import settings

class PylintAnalyzer:
    SEVERITY_MAPPING = {
        "convention": "LOW",
        "refactor": "LOW",
        "warning": "MEDIUM",
        "error": "HIGH",
        "fatal": "CRITICAL"
    }

    def __init__(self, repo_path):
        self.repo_path = repo_path
        self.output_dir = os.path.join(settings.MEDIA_ROOT, 'analysis_results')
        os.makedirs(self.output_dir, exist_ok=True)

    def run_analysis(self):
        json_path = os.path.join(self.output_dir, 'pylint.json')
        
        try:
            result = subprocess.run(
                ["pylint", "--recursive=y", self.repo_path, "--output-format=json"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            if result.stderr:
                print(f"Pylint stderr: {result.stderr}")

            try:
                data = json.loads(result.stdout)
            except json.JSONDecodeError:
                data = []

            issues = []
            for entry in data:
                severity = self.SEVERITY_MAPPING.get(entry.get("type", ""), "LOW")
                issues.append({
                    'tool': 'pylint',
                    'filename': entry.get("path", ""),
                    'line_number': entry.get("line", 0),
                    'severity': severity,
                    'message': entry.get("message", ""),
                    'type': entry.get("type", ""),
                    'symbol': entry.get("symbol", "")
                })

            return issues

        except Exception as e:
            print(f"Pylint analysis error: {str(e)}")
            return []
