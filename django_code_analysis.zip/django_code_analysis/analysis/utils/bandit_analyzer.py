import json
import csv
import subprocess
from django.conf import settings
import os

class BanditAnalyzer:
    def __init__(self, repo_path):
        self.repo_path = repo_path
        self.output_dir = os.path.join(settings.MEDIA_ROOT, 'analysis_results')
        os.makedirs(self.output_dir, exist_ok=True)

    def run_analysis(self):
        json_path = os.path.join(self.output_dir, 'bandit_output.json')
        csv_path = os.path.join(self.output_dir, 'bandit_output.csv')

        try:
            # Run Bandit
            result = subprocess.run(
                ["bandit", "-r", self.repo_path, "-iii", "-ll", "-f", "json", "-o", json_path],
                cwd=self.repo_path,
                text=True,
                capture_output=True
            )

            if result.returncode not in [0, 1]:
                raise Exception("Bandit execution failed")

            # Process results
            with open(json_path) as f:
                data = json.load(f)

            if not data or "results" not in data:
                return []

            # Convert to Django model compatible format
            issues = []
            for result in data["results"]:
                issues.append({
                    'tool': 'bandit',
                    'filename': result.get("filename"),
                    'line_number': result.get("line_number"),
                    'severity': result.get("issue_severity", "").upper(),
                    'message': result.get("issue_text", ""),
                    'confidence': result.get("issue_confidence", ""),
                    'test_id': result.get("test_id", "")
                })

            return issues

        except Exception as e:
            print(f"Bandit analysis error: {str(e)}")
            return []
