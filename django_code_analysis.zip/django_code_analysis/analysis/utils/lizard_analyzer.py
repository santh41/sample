import subprocess
import json

class LizardAnalyzer:
    def __init__(self, repo_path):
        self.repo_path = repo_path

    def run_analysis(self):
        try:
            result = subprocess.run(
                ["lizard", "-l", "python", self.repo_path],
                capture_output=True,
                text=True
            )

            if "NLOC" not in result.stdout:
                raise Exception("No valid Lizard output")

            issues = []
            for line in result.stdout.split("\n"):
                parts = line.split()
                if len(parts) >= 6 and parts[1].isdigit():
                    complexity = int(parts[1])
                    severity = self._get_severity(complexity)
                    
                    issues.append({
                        'tool': 'lizard',
                        'filename': parts[-1],
                        'function_name': parts[5].split("@")[0],
                        'line_number': parts[5].split("@")[1].split("-")[0],
                        'severity': severity,
                        'message': f"Cyclomatic complexity: {complexity}",
                        'complexity': complexity
                    })

            return issues
        except Exception as e:
            print(f"Lizard analysis error: {str(e)}")
            return []

    def _get_severity(self, complexity):
        if complexity <= 5:
            return 'LOW'
        elif 6 <= complexity <= 10:
            return 'MEDIUM'
        elif 11 <= complexity <= 20:
            return 'HIGH'
        return 'CRITICAL'
