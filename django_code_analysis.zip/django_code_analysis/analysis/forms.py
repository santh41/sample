from django import forms
from analysis.models import AnalysisProject

class AnalysisProjectForm(forms.ModelForm):
    class Meta:
        model = AnalysisProject
        fields = ['name', 'github_url']
        widgets = {
            'github_url': forms.URLInput(attrs={'placeholder': 'https://github.com/user/repo'}),
        }
