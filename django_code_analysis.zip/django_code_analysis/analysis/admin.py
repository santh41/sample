##from django.contrib import admin
# Register your models here.
"""
from django.contrib import admin
from analysis.models import AnalysisProject, AnalysisResult

class AnalysisResultInline(admin.TabularInline):
    model = AnalysisResult
    extra = 0
    readonly_fields = ('tool', 'filename', 'line_number', 'severity', 'message')
    can_delete = False

@admin.register(AnalysisProject)
class AnalysisProjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'github_url', 'created_at')
    inlines = [AnalysisResultInline]

@admin.register(AnalysisResult)
class AnalysisResultAdmin(admin.ModelAdmin):
    list_display = ('project', 'tool', 'filename', 'line_number', 'severity')
    list_filter = ('tool', 'severity', 'project')
    search_fields = ('filename', 'message')
"""
from django.contrib import admin
from analysis.models import AnalysisProject, AnalysisResult
from django.core.management import call_command
from django.contrib import messages

@admin.register(AnalysisProject)
class AnalysisProjectAdmin(admin.ModelAdmin):
    list_display = ('name', 'github_url', 'created_at')
    actions = ['run_analysis']

    def run_analysis(self, request, queryset):
        for project in queryset:
            try:
                call_command('run_analysis', project.id)
                self.message_user(request, f"Analysis completed for {project.name}", messages.SUCCESS)
            except Exception as e:
                self.message_user(request, f"Error analyzing {project.name}: {str(e)}", messages.ERROR)
    run_analysis.short_description = "Run analysis on selected projects"
