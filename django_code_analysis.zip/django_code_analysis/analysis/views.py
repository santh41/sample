##from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, CreateView
from analysis.models import AnalysisProject, AnalysisResult
from analysis.forms import AnalysisProjectForm
from django.urls import reverse_lazy

class ProjectListView(ListView):
    model = AnalysisProject
    template_name = 'analysis/project_list.html'
    context_object_name = 'projects'

class ProjectDetailView(DetailView):
    model = AnalysisProject
    template_name = 'analysis/project_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['results'] = AnalysisResult.objects.filter(project=self.object)
        context['project_id'] = self.object.id  # Add this line

        return context

class ProjectCreateView(CreateView):
    model = AnalysisProject
    form_class = AnalysisProjectForm
    template_name = 'analysis/project_create.html'
    success_url = reverse_lazy('project_list')

def run_analysis(request, pk):
    from django.core.management import call_command
    from analysis.models import AnalysisProject
    from django.contrib import messages
    
    project = AnalysisProject.objects.get(pk=pk)
    try:
        call_command('run_analysis', project.id)
        messages.success(request, 'Analysis completed successfully!')
    except Exception as e:
        messages.error(request, f'Error during analysis: {str(e)}')
    
    return redirect('project_detail', pk=pk)
