from django.core.management.base import BaseCommand
from analysis.models import AnalysisProject, AnalysisResult
from analysis.utils import (
    BanditAnalyzer,
    LizardAnalyzer,
    PylintAnalyzer,
    RadonAnalyzer,
    SonarQubeAnalyzer
)
import tempfile
import shutil
import os
import subprocess

class Command(BaseCommand):
    help = 'Runs code analysis tools on a GitHub repository'

    def add_arguments(self, parser):
        parser.add_argument('project_id', type=int, help='ID of the AnalysisProject')

    def handle(self, *args, **options):
        project = AnalysisProject.objects.get(id=options['project_id'])
        self.stdout.write(f"Starting analysis for project: {project.name}")
        
        with tempfile.TemporaryDirectory() as temp_dir:
            repo_path = self.clone_repo(project.github_url, temp_dir)
            self.run_analysis_tools(repo_path, project)

    def clone_repo(self, git_url, dest_folder):
        """Clones the GitHub repo to a temporary directory"""
        if os.path.exists(dest_folder):
            shutil.rmtree(dest_folder)
        self.stdout.write(f"Cloning repository: {git_url}...")
        subprocess.run(["git", "clone", git_url, dest_folder], check=True)
        return os.path.abspath(dest_folder)

    def run_analysis_tools(self, repo_path, project):
        """Run all analysis tools and save results"""
        tools = [
            ('bandit', BanditAnalyzer(repo_path)),
            ('lizard', LizardAnalyzer(repo_path)),
            ('pylint', PylintAnalyzer(repo_path)),
            ('radon', RadonAnalyzer(repo_path)),
            ('sonarqube', SonarQubeAnalyzer(repo_path))
        ]

        # Clear old results
        AnalysisResult.objects.filter(project=project).delete()

        for tool_name, analyzer in tools:
            self.stdout.write(f"Running {tool_name} analysis...")
            try:
                issues = analyzer.run_analysis()
                self.save_results(issues, project)
            except Exception as e:
                self.stderr.write(f"Error in {tool_name}: {str(e)}")

    def save_results(self, issues, project):
        """Save analysis results to database"""
        for issue in issues:
            AnalysisResult.objects.create(
                project=project,
                tool=issue['tool'],
                filename=issue['filename'],
                line_number=issue.get('line_number'),
                function_name=issue.get('function_name', ''),
                severity=issue['severity'],
                message=issue['message'],
                confidence=issue.get('confidence', ''),
                test_id=issue.get('test_id', '')
            )
